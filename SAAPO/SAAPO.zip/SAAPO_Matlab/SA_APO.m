% Energy-Efficient Robotic Arm Trajectory Optimization Using a Surrogate-Assisted Artificial Protozoa Optimizer
function [bestProtozoa,gbest,recordtime] = SA_APO(dim,train_data,Xmax,Xmin)
% random seeds
    stm = RandStream('swb2712','Seed',sum(100*clock));
    RandStream.setGlobalStream(stm);

    ps = 100;       % ps denotes protozoa size
    np = 1;         % np denotes neighbor pairs     np_max can be set in floor((ps-1)/2)
    pf_max = 0.1;   % pf_max denotes proportion fraction maximum 
    iter_max = 100; % maximum iteration 
tic; 
protozoa=zeros(ps,dim);    % protozoa
newprotozoa=zeros(ps,dim); % new protozoa
epn=zeros(np,dim); % epn denotes effect of paired neighbors

T = 10;
nc = dim; % Number of neurons of RBF models 等于 dim
%% train RBF
train_hx = train_data(:,1:dim);
train_hf = train_data(:,end);
  
%Build Model Pool
[W,B,C,S] = RBF_EnsembleUN(train_data,dim,nc,T);
I=[1:T];
% initilization - Latin hypercube sampling (LHS)
protozoa = lhsdesign(ps,dim).*(ones(ps,1)*(Xmax-Xmin))+ones(ps,1)*Xmin;
% protozoa_Fit= mean(RBF_Ensemble_predictor(W(I,:),B(I),C(:,:,I),S(:,I),protozoa,dim),2)';
% find the bestProtozoa and bestFit
[bestval,bestid] = min(train_hf);
bestProtozoa = train_hx(bestid,:);  % bestProtozoa
bestFit = bestval; % bestFit
gbest = bestProtozoa;

fit_dataset= RBF_Ensemble_predictor(W(I,:),B(I),C(:,:,I),S(:,I),train_hx,dim);
%%  Main loop  
for iter= 2:iter_max
    pf = pf_max*rand; % proportion fraction
    ri=randperm(ps,ceil(ps*pf)); % rank index of protozoa in dormancy or reproduction forms   
    for i=1:ps
        if ismember(i,ri) %  protozoa is in dormancy or reproduction form  
           pdr=1/2*(1+cos((1-i/ps)*pi)); % probability of dormancy and reproduction
           if rand<pdr  % dormancy form
                newprotozoa(i,:)=  Xmin + rand(1,dim).*(Xmax-Xmin); 
           else  % reproduction form
                flag=[1,-1];  % +- (plus minus) 
                Flag=flag(ceil(2*rand));  
                Mr=zeros(1,dim); % Mr is a mapping vector in reproduction
                Mr(1,randperm(dim,ceil(rand*dim)))=1;
                newprotozoa(i,:)= protozoa(i,:) + Flag*rand*(Xmin+rand(1,dim).*(Xmax-Xmin)).*Mr; 
           end
        else  % protozoa is foraging form
           f= rand*(1+cos(iter/iter_max*pi)); % foraging factor
           Mf=zeros(1,dim);  % Mf is a mapping vector in foraging
           Mf(1,randperm(dim,ceil(dim*i/ps)))=1;
           pah= 1/2*(1+cos(iter/iter_max*pi)); % probability of autotroph and heterotroph 
           if rand<pah  % protozoa is in autotroph form            
            j= randperm(ps,1); % j denotes the jth randomly selected protozoa
            for k=1:np % np denotes neighbor pairs  
              if i==1
                 km=i; % km denotes the k- (k minus)
                 kp=i+randperm(ps-i,1); % kp denotes the k+ (k plus)
              elseif i==ps
                 km=randperm(ps-1,1);
                 kp=i;
              else
                 km=randperm(i-1,1);
                 kp=i+randperm(ps-i,1);
              end
              % wa denotes weight factor in the autotroph forms
%               wa=exp(-abs(protozoa_Fit(1,km)/(protozoa_Fit(1,kp)+eps))); 
              wa=exp(-(1-km/kp)); 
              % epn denotes effect of paired neighbors 
              epn(k,:)=wa*(protozoa(km,:)-protozoa(kp,:));             
            end                         
            newprotozoa(i,:)= protozoa(i,:)+ f*(protozoa(j,:)-protozoa(i,:)+1/np*sum(epn,1)).*Mf;         
            
         else   % protozoa is in heterotroph form   
            for k=1:np % np denotes neighbor pairs 
             if i==1
                 imk=i;   % imk denotes i-k (i minus k)
                 ipk=i+k; % ipk denotes i+k (i plus k)
             elseif i==ps
                 imk=ps-k;
                 ipk =i;
             else
                 imk=i-k;
                 ipk=i+k;
             end
             % neighbor limit range in [1,ps]
             if  imk<1
                    imk=1;
             elseif ipk>ps
                    ipk=ps;
             end
             % denotes weight factor in the heterotroph form
%              wh=exp(-abs(protozoa_Fit(1,imk)/(protozoa_Fit(1,ipk)+eps)));
             wh=exp(-(1-imk/ipk)); 
             epn(k,:)=wh*(protozoa(imk,:)-protozoa(ipk,:));
            end           
             flag=[1,-1];  % +- (plus minus) 
             Flag=flag(ceil(2*rand));             
             Xnear=(1+Flag*rand(1,dim)*(1-iter/iter_max)).* protozoa(i,:);
             newprotozoa(i,:)=protozoa(i,:)+f*(Xnear-protozoa(i,:)+1/np*sum(epn,1)).*Mf;              
          end
       end
   end
       newprotozoa = ((newprotozoa>=Xmin)&(newprotozoa<=Xmax)).*newprotozoa...
                     +(newprotozoa<Xmin).*Xmin+(newprotozoa>Xmax).*Xmax; 
    protozoa=[protozoa;newprotozoa];
%% Model Selection_Non-Dominated Sorting
% Calculate Euclidean distance
distances = sqrt(sum((train_hx - bestProtozoa).^2, 2));
[~, sortedIndices] = sort(distances);
% M nearest neighbor indices
num_neighbor = round(0.1*log(dim)*length(train_hx)); 
closestIndices = sortedIndices(1:num_neighbor);
% RMSE
n = length(closestIndices); 
rmse = sqrt(sum((fit_dataset(closestIndices,:) - train_hf(closestIndices,:)).^2) / n);
% predict the x_best
x_best_predict = RBF_Ensemble_predictor(W(I,:),B(I),C(:,:,I),S(:,I),bestProtozoa,dim);
FunctionValue=[rmse',x_best_predict'];
% non-dominated sorting
FrontValue = NonDominateSort(FunctionValue,0); 
% Index with Pareto front of 1
I_select =  find(FrontValue == 1);
%%
% evaluate fitness value
protozoa_Fit= mean(RBF_Ensemble_predictor(W(I_select,:),B(I_select),C(:,:,I_select),S(:,I_select),protozoa,dim),2)';

[protozoa_Fit,index] = sort(protozoa_Fit); 
protozoa= protozoa(index(1:ps),:); 
protozoa_Fit= protozoa_Fit(1,1:ps);

bestProtozoa = protozoa(1,:); 
gbest = [gbest;bestProtozoa];

 end
    recordtime = toc;
end