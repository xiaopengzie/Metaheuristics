% Energy-Efficient Robotic Arm Trajectory Optimization Using a Surrogate-Assisted Artificial Protozoa Optimizer
close all;
clc;clear;

fun_nums = 5; 
runs = 20;
dim = 100; 

bd=[-5.12,-2.048,-32.768,-600,-5.12];
bu=[5.12,2.048,32.768,600,5.12];

% xbest 
xbest(runs,dim) = inf;
xbest(:) = inf;
% fbest 
fbest(fun_nums,runs) = inf;
fbest(:) = inf;
% f_median 
f_median(fun_nums) = inf;
f_median(:) = inf;
% f_mean 
f_mean(fun_nums) = inf;
f_mean(:) = inf;
% f_std 
f_std(fun_nums) = inf;
f_std(:) = inf;
% f_time
f_time(fun_nums,runs) = inf;
f_time(:) = inf;

fname = ['SA_APO_',num2str(dim),'D.txt'];
f_out_name = fopen(fname,'wt');
fname_b_w_med_mean_std_time = ['record_SA_APO_b_w_med_mean_std_time_',num2str(dim),'D.txt'];% record best, mean,std and time (runs)
f_out_b_w_med_mean_std_time = fopen(fname_b_w_med_mean_std_time,'wt');
ftime = ['SA_APO_Time_',num2str(dim),'D.txt'];
f_out_time = fopen(ftime,'wt');

for i=1:fun_nums
    func=i;
    disp(['Fid:',num2str(func)]);
    fprintf(f_out_name,'Fid:%d\n',func);
    fprintf(f_out_time,'Fid:%d\n',func);
    
    Xmin=ones(1,dim)*bd(func);
    Xmax=ones(1,dim)*bu(func);
    for j=1:runs
        offsize=11*dim;
        offdata=lhsdesign(offsize,dim).*(ones(offsize,1)*(Xmax-Xmin))+ones(offsize,1)*Xmin;   
        %offdata=rand(offsize,dim).*(ones(offsize,1)*(Xmax-Xmin))+ones(offsize,1)*Xmin;
        offy=bench_func(offdata,func); 
        Data=[offdata offy];
        
        [gbest,gbest_convergence,recordtime]=SA_APO(dim,Data,Xmax,Xmin);
        xbest(j,:) = gbest; 
        fbest(i,j)= bench_func(gbest,func);
        
        disp(['x[',num2str(gbest),']=',num2str(fbest(i,j),15)]);
        fprintf(f_out_name,'x%s\t[%s]=%s\n',num2str(j),num2str(gbest),num2str(fbest(i,j)));
        f_time(i,j) = recordtime;
        fprintf(f_out_time,'Time[%s]=\t%.15f\n',num2str(j),f_time(i,j));
    end
    [bestval,bestindex] = min(fbest(i,:));
    locb = xbest(bestindex,:); % best solution in runs
    disp(['best[',num2str(locb),']=',num2str(bestval,15)]);
    fprintf(f_out_name,'best[%s]=%s\n',num2str(locb),num2str(bestval));
    [worstval,worstindex] = max(fbest(i,:)); 
    locw = xbest(worstindex,:); % worst solution in runs
    disp(['worst[',num2str(locw),']=',num2str(worstval,15)]);
    fprintf(f_out_name,'worst[%s]=%s\n',num2str(locw),num2str(worstval));
    f_median(i) = median(fbest(i,:));
    disp(['median[',num2str(i),']=',num2str(f_median(i),15)]);
    fprintf(f_out_name,'median[%s]=%s\n',num2str(i),num2str(f_median(i)));
    f_mean(i)=mean(fbest(i,:));
    disp(['mean[',num2str(i),']=',num2str(f_mean(i),15)]);
    fprintf(f_out_name,'mean[%s]=%s\n',num2str(i),num2str(f_mean(i)));
    f_std(i) = std(fbest(i,:));
    disp(['std[',num2str(i),']=',num2str(f_std(i),15)]);
    fprintf(f_out_name,'std[%s]=%s\n',num2str(i),num2str(f_std(i)));

    fprintf(f_out_name,'runs_fitness[%s]=%s\n',num2str(i),num2str(fbest(i,:))); % runs all fitness
    
    MeanT=mean(f_time(i,:));
    disp(['MeanTime[',num2str(i),']=',num2str(MeanT,15)]);
    fprintf(f_out_time,'MeanTime[%s]=\t%.15f\n',num2str(i),MeanT);
    
    best_worst_median_mean_std(i,1)=i; 
    best_worst_median_mean_std(i,2)=bestval;
    best_worst_median_mean_std(i,3)=worstval;
    best_worst_median_mean_std(i,4)=f_median(i);
    best_worst_median_mean_std(i,5)=f_mean(i);
    best_worst_median_mean_std(i,6)=f_std(i);
    best_worst_median_mean_std(i,7)=MeanT;
    best_worst_median_mean_std(i,8)=bestindex;
    fprintf(f_out_b_w_med_mean_std_time,'%s\n',num2str(best_worst_median_mean_std(i,:)));
end
fclose(f_out_name);
fclose(f_out_time);
fclose(f_out_b_w_med_mean_std_time);
clear all;
