function [ Y ] = RBF_Ensemble_predictor( W,B,C,S,U,c )
% Usage: [ Y ] = RBF_Ensemble_predictor( W,B,C,S,U,c )
%RBF Predictors 
% Input:
% W             - Weights of RBF Models
% B             - Bais of RBF Models
% C             - Centers of RBF Models
% S             - Widths of RBF models
% U             - Test Data with c Decision Variables
% c             - Number of Decision Variables
%
% Output: 
% Y             - Predictions of RBF Models for U

Y=[];
T=size(B,2);%Number of RBF models
for i=1:T
    Yhat=RBF_predictor(W(i,:),B(i),C(:,:,i),S(:,i),U(:,1:c));
    Y=[Y,Yhat];
end

end
